import "@/App.css";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { LanguageProvider } from "./context/LanguageContext";
import { AuthProvider } from "./context/AuthContext";
import { Toaster } from "./components/ui/sonner";

import HomePage from "./pages/HomePage";
import BookingPage from "./pages/BookingPage";
import ConfirmationPage from "./pages/ConfirmationPage";
import InvoicePage from "./pages/InvoicePage";
import BankTransferPage from "./pages/BankTransferPage";
import TransferPage from "./pages/TransferPage";
import AdminLoginPage from "./pages/AdminLoginPage";
import AdminDashboard from "./pages/AdminDashboard";

function App() {
  return (
    <LanguageProvider>
      <AuthProvider>
        <BrowserRouter>
          <Routes>
            <Route path="/" element={<HomePage />} />
            <Route path="/booking/:hotelId" element={<BookingPage />} />
            <Route path="/booking/confirmation" element={<ConfirmationPage />} />
            <Route path="/invoice/:bookingId" element={<InvoicePage />} />
            <Route path="/booking/transfer/:bookingId" element={<BankTransferPage />} />
            <Route path="/transfer" element={<TransferPage />} />
            <Route path="/transfer/:token" element={<TransferPage />} />
            <Route path="/admin/login" element={<AdminLoginPage />} />
            <Route path="/admin/*" element={<AdminDashboard />} />
          </Routes>
          <Toaster position="top-right" />
        </BrowserRouter>
      </AuthProvider>
    </LanguageProvider>
  );
}

export default App;
